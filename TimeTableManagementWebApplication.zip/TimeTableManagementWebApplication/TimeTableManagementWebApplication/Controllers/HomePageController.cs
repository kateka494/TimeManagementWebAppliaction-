﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeTableManagementWebApplication.Classes;
using TimeTableManagementWebApplication.Models;

namespace TimeTableManagementWebApplication.Controllers
{
    public class HomePageController : Controller
    {
        private readonly ConnectClass connec;

        public HomePageController(ConnectClass conn)
        {
            connec = conn;
        }

        public IActionResult HomePage()
        {
            return View();
        }

        [HttpPost]
        [ValidateAntiForgeryToken]
        public IActionResult HomePage(ModuleClass mod)
        {
            connec.Add(mod);
            connec.SaveChanges();
            ViewBag.message = $"The Record {mod.CODE} is Saved Succesfully .......!";
            return View();
        }

        public IActionResult HomePageCapturedData()
        {
            return View(connec.MODULE_INFO.ToList());
        }
    }
}
