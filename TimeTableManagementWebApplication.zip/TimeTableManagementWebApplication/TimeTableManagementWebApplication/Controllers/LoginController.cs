﻿using Microsoft.AspNetCore.Mvc;
using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using TimeTableManagementWebApplication.Classes;

namespace TimeTableManagementWebApplication.Controllers
{
    public class LoginController : Controller
    {
        //Get: Account
        [HttpGet]
        public IActionResult Login()
        {
            return View();
        }

        [HttpPost]//This is for action method - methods that perform action
        public IActionResult verifiedLogin(Student stu)
        {
            string studentNum, password;
            studentNum = Request.Form["Student_Number"].ToString();
            password = Request.Form["Password"].ToString();

            bool isValid = stu.IsSuccessLogin(studentNum, password);

            if (isValid)
            {
                return RedirectToAction("HomePage", "HomePage");

            }
            else
            {
                return View("Login");
            }

        }
    }
}
