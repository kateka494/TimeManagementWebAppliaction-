﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.Data;
using System.Data.SqlClient;

namespace TimeTableManagementWebApplication.Classes
{
    public class Student
    {
        SqlConnection conn = new SqlConnection("Data Source=(localdb)\\MSSQLLocalDB;Integrated Security=True");
        public string studentNum { get; set; }
        public string Username { get; set; }
        public string Password { get; set; }

        public Student()
        {
            this.studentNum = "";
            this.Username = "No name";
            this.Password = "No password";
        }
        public Student(string stuNum, string name, string pass)
        {
            studentNum = stuNum;
            Username = name;
            Password = pass;
        }

        public List<Student> GetStudent()
        {
            List<Student> ls = new List<Student>();
            SqlDataAdapter cmdSelect = new SqlDataAdapter($"SELECT * FROM dbo.STUDENT_INFO", conn);
            DataTable dt = new DataTable();
            DataRow dr;

            conn.Open();
            cmdSelect.Fill(dt);

            if (dt.Rows.Count > 0)
            {

                for (int i = 0; i < dt.Rows.Count; i++)
                {
                    dr = dt.Rows[i];
                    ls.Add(new Student((string)dr[0], (string)dr[1], (string)dr[2]));
                }
            }

            conn.Close();

            return ls;

        }

        public bool IsSuccessLogin(string studentNum, string pass)
        {
            SqlDataAdapter cmdSelect = new SqlDataAdapter($"SELECT * FROM dbo.STUDENT_INFO WHERE STUDENT_NUMBER = '{studentNum}' AND STUDENT_PASS = '{pass}'", conn);
            DataTable dt = new DataTable();

            conn.Open();
            cmdSelect.Fill(dt);

            conn.Close();

            return dt.Rows.Count > 0;
        }

    }
}
