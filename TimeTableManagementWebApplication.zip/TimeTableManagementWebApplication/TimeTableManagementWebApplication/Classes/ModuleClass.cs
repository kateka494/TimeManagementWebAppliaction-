﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;
using myLibrary2;

namespace TimeTableManagementWebApplication.Classes
{
    public class ModuleClass
    {
        [Key]
        public string CODE { get; set; }
        [Required]
        public string MODULE_NAME { get; set; }
        [Required]
        public int NUM_OF_CREDITS { get; set; }
        [Required]
        public int CLASS_HRS_WEEK { get; set; }
        [Required]
        public int NUM_OF_WEEKS { get; set; }
        [Required]
        public DateTime START_DATE { get; set; }
        //declared variable
        int self;
        public int Self_Study_Hours 
        {
            set { self = ((NUM_OF_CREDITS * 10) / NUM_OF_WEEKS) - CLASS_HRS_WEEK; }
            get { return self; }
        }


    }
}
