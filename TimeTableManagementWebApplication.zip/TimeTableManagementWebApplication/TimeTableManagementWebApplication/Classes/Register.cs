﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using System.ComponentModel.DataAnnotations;

namespace TimeTableManagementWebApplication.Classes
{
    public class Register
    {
        [Key]
        public string STUDENT_NUMBER { get; set; }
        [Required]
        public string STUDENT_NAME { get; set; }
        [Required]
        public string STUDENT_PHONENUM { get; set; }
        [Required]
        public string STUDENT_EMAIL { get; set; }
        [Required]
        public string STUDENT_PASS { get; set; }
    }
}
